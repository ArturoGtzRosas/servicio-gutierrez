import ssl
from urllib.parse import urlparse
from datetime import datetime
import pg8000.native

# Conexión directa a Neon
URL_NEON = "postgresql://neondb_owner:npg_pLb7DaKABwP8@ep-crimson-king-b8k1d6z4-pooler.c-14.us-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require"

def respaldar_produccion():
    fecha_hoy = datetime.now().strftime("%Y_%m_%d_%H%M%S")
    nombre_archivo = f"respaldo_neon_prod_{fecha_hoy}.sql"

    print("[*] Conectando a la base de datos de Neon (Producción)...")

    try:
        url = urlparse(URL_NEON)
        ssl_context = ssl.create_default_context()

        conn = pg8000.native.Connection(
            user=url.username,
            password=url.password,
            host=url.hostname,
            port=url.port or 5432,
            database=url.path.lstrip('/'),
            ssl_context=ssl_context,
            timeout=15
        )

        tablas = [
            'usuarios',
            'notas_venta',
            'presupuestos',
            'cotizaciones',
            'mensajes_contacto',
            'licencias_office',
            'licencias_antivirus'
        ]

        with open(nombre_archivo, 'w', encoding='utf-8') as f:
            f.write("-- RESPALDO DE PRODUCCION (NEON) - G-TEK SOLUCIONES DIGITALES\n")
            f.write(f"-- Fecha de descarga: {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n\n")

            for tabla in tablas:
                try:
                    filas = conn.run(f"SELECT * FROM {tabla}")
                    
                    cols_info = conn.run(
                        "SELECT column_name FROM information_schema.columns "
                        "WHERE table_name = :t ORDER BY ordinal_position",
                        t=tabla
                    )
                    columnas = [c[0] for c in cols_info]

                    f.write(f"-- Datos de la tabla: {tabla}\n")
                    for fila in filas:
                        valores = []
                        for val in fila:
                            if val is None:
                                valores.append("NULL")
                            elif isinstance(val, (int, float)):
                                valores.append(str(val))
                            else:
                                txt = str(val).replace("'", "''")
                                valores.append(f"'{txt}'")

                        cols_str = ", ".join(columnas)
                        vals_str = ", ".join(valores)
                        f.write(f"INSERT INTO {tabla} ({cols_str}) VALUES ({vals_str});\n")

                    f.write("\n")
                    print(f"  [+] Tabla '{tabla}' respaldada con exito ({len(filas)} registros).")
                except Exception as e_tab:
                    print(f"  [-] Omitiendo tabla '{tabla}': {e_tab}")

            conn.close()

        print(f"\n[OK] Respaldo de produccion descargado exitosamente: {nombre_archivo}")

    except Exception as e:
        print(f"\n[ERROR] No se pudo conectar a Neon: {e}")

if __name__ == '__main__':
    respaldar_produccion()