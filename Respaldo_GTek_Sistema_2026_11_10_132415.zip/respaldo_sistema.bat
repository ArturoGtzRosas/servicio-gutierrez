@echo off
title Respaldo del Sistema - G-Tek Soluciones Digitales
echo ========================================================
echo   RESPALDO INTEGRAL DEL SISTEMA - G-TEK SOLUCIONES
echo ========================================================
echo.
echo Selecciona en la ventana emergente la carpeta donde deseas guardar la copia...

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "Add-Type -AssemblyName System.Windows.Forms;" ^
  "$f = New-Object System.Windows.Forms.FolderBrowserDialog;" ^
  "$f.Description = 'Selecciona la carpeta de destino para el respaldo';" ^
  "if ($f.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {" ^
  "  $destino = $f.SelectedPath;" ^
  "  $origen = (Get-Location).Path;" ^
  "  $timestamp = (Get-Date).ToString('yyyy_MM_dd_HHmmss');" ^
  "  $archivoZip = Join-Path $destino ('Respaldo_GTek_Sistema_' + $timestamp + '.zip');" ^
  "  Write-Host '[*] Carpeta origen: ' $origen -ForegroundColor Cyan;" ^
  "  Write-Host '[*] Destino: ' $archivoZip -ForegroundColor Cyan;" ^
  "  Write-Host '[*] Comprimiendo archivos (omitiendo venv y cache)...' -ForegroundColor Yellow;" ^
  "  $excluir = @('venv', '.venv', '__pycache__', '.git');" ^
  "  $tempDir = Join-Path $env:TEMP ('GTek_Temp_' + $timestamp);" ^
  "  New-Item -ItemType Directory -Path $tempDir -Force | Out-Null;" ^
  "  Get-ChildItem -Path $origen -Exclude $excluir | ForEach-Object {" ^
  "    Copy-Item -Path $_.FullName -Destination $tempDir -Recurse -Force" ^
  "  };" ^
  "  Compress-Archive -Path (Join-Path $tempDir '*') -DestinationPath $archivoZip -Force;" ^
  "  Remove-Item -Path $tempDir -Recurse -Force;" ^
  "  Write-Host '[OK] Respaldo generado con exito:' $archivoZip -ForegroundColor Green;" ^
  "} else {" ^
  "  Write-Host '[!] Operacion cancelada por el usuario.' -ForegroundColor Yellow;" ^
  "}"

echo.
pause