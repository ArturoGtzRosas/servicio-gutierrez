-- RESPALDO G-TEK SOLUCIONES DIGITALES
-- Generado: 28/10/2026 09:33:13

-- Datos de la tabla: usuarios
INSERT INTO usuarios (id, nombre, email, password, rol) VALUES (1, 'Arturo', 'arturo@servicio.com', 'pbkdf2:sha256:600000$nHuR13I2Ff7lbG3f$068590d002ed418c502559ca01cd15231cc2e8b08ca78a076d7b45bce71526aa', 'admin');

-- Datos de la tabla: notas_venta
INSERT INTO notas_venta (id, fecha, cliente, direccion, telefono, equipo, servicio, total, observaciones) VALUES (1, '15/10/2026 12:47', 'Supervisión Escolar J212', 'Emiliano Zapata s/n, Santa María Nativitas, Chimalhuacán, Estado de México.', '55 3013 1070', 'Laptop Lanix', 'Office 2024 Professional Plus', 650.0, 'Sin Paqueteria');
INSERT INTO notas_venta (id, fecha, cliente, direccion, telefono, equipo, servicio, total, observaciones) VALUES (2, '15/10/2026 13:08', 'J.N Unidos Avanzamos', 'Chimalhuacan', '55 2523 8965', 'Laptop Hp 240 G5', '(x2) Office Professional Plus 2024', 1300.0, 'Sin office');
INSERT INTO notas_venta (id, fecha, cliente, direccion, telefono, equipo, servicio, total, observaciones) VALUES (3, '15/10/2026 13:13', 'Maestra Monse', 'Chicoloapan', '55 1234 5678', 'Laptop Asus', '(x3) Office Professional Plus 2024', 1950.0, 'Sin office');

-- Datos de la tabla: presupuestos
INSERT INTO presupuestos (id, fecha, cliente, telefono, equipo, servicios, total) VALUES (3, '09/10/2026 10:53', 'Jardín de niños "Unidos Avanzamos"', '55 2324 7898', 'Sistema de Video Vigilancia', '(x1) DVR con conexión a Internet, (x8) Cámara para exteriores', 8800.0);
INSERT INTO presupuestos (id, fecha, cliente, telefono, equipo, servicios, total) VALUES (4, '09/10/2026 11:59', 'Arturo Gtz', '55 4031 3150', 'Laptop Asus', '(x1) Memoria RAM DDR4 8 GB', 2200.0);

-- Datos de la tabla: cotizaciones
INSERT INTO cotizaciones (id, nombre, servicio, modelo, fecha_registro) VALUES (1, 'Juan P', 'bateria', 'Hp G5', '2026-02-13 19:14:00');

