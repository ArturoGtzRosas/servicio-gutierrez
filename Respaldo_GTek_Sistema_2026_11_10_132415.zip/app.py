from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify, abort
import sqlite3
import math
from fpdf import FPDF
import os
import subprocess
import hmac
import hashlib
import smtplib
from email.mime.base import MIMEBase
from email import encoders
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from werkzeug.security import generate_password_hash, check_password_hash
import requests
import base64
import qrcode
import io
import json
import re

RESEND_API_KEY = os.environ.get('RESEND_API_KEY', '')
BREVO_API_KEY = os.environ.get('BREVO_API_KEY', '')


# Parche de compatibilidad para ReportLab en Python 3.8
_orig_md5 = hashlib.md5
def _patched_md5(*args, **kwargs):
    kwargs.pop('usedforsecurity', None)
    return _orig_md5(*args, **kwargs)
hashlib.md5 = _patched_md5
from datetime import datetime
from flask import send_file

app = Flask(__name__)
app.secret_key = 'servicio_gutierrez_master_key_2026'

APP_VERSION = "v2.2.0"

@app.context_processor
def inject_version():
    return dict(app_version=APP_VERSION)

MAIL_SERVER = 'smtp.gmail.com'
MAIL_PORT = 465
MAIL_USERNAME = 'serviciogutierrezpc@gmail.com'
MAIL_PASSWORD = 'sondiuxeuddmtspx'
MAIL_SENDER = 'G-Tek Soluciones Digitales <serviciogutierrezpc@gmail.com>'

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

try:
    import psycopg2
    from psycopg2.extras import RealDictCursor
except ImportError:
    psycopg2 = None
    RealDictCursor = None

DATABASE_URL = os.environ.get('DATABASE_URL')
DATABASE_SQLITE = os.path.join(BASE_DIR, 'servicio_gutierrez.db')

class DBConnectionWrapper:
    """Adaptador para que la conexion a PostgreSQL se comporte igual que SQLite."""
    def __init__(self, conn, is_pg=False):
        self.conn = conn
        self.is_pg = is_pg

    def cursor(self):
        return self.conn.cursor()

    def execute(self, query, params=None):
        cur = self.conn.cursor()
        if self.is_pg:
            query = query.replace('?', '%s')
        if params is not None:
            cur.execute(query, params)
        else:
            cur.execute(query)
        return cur

    def commit(self):
        self.conn.commit()

    def rollback(self):
        self.conn.rollback()

    def close(self):
        self.conn.close()


def get_db_connection():
    if DATABASE_URL and psycopg2:
        # Conexion a PostgreSQL en Render (Neon)
        conn = psycopg2.connect(DATABASE_URL, cursor_factory=RealDictCursor)
        return DBConnectionWrapper(conn, is_pg=True)
    else:
        # Respaldo SQLite en local si no existe DATABASE_URL o psycopg2
        conn = sqlite3.connect(DATABASE_SQLITE)
        conn.row_factory = sqlite3.Row
        return DBConnectionWrapper(conn, is_pg=False)

def migrar_db_email():
    try:
        db = get_db_connection()
        db.execute("ALTER TABLE presupuestos ADD COLUMN email TEXT")
        if hasattr(db.conn, 'commit'):
            db.conn.commit()
        db.close()
    except Exception:
        # Si la columna ya existe o falla el alter, continúa con normalidad
        pass

migrar_db_email()

def migrar_db_notas_email():
    try:
        conn = get_db_connection()
        conn.execute("ALTER TABLE notas_venta ADD COLUMN email TEXT")
        conn.commit()
        conn.close()
    except Exception:
        pass

migrar_db_notas_email()

def migrar_db_notas_estatus():
    try:
        conn = get_db_connection()
        conn.execute("ALTER TABLE notas_venta ADD COLUMN estatus TEXT DEFAULT 'En Diagnóstico'")
        conn.commit()
        conn.close()
    except Exception:
        pass

migrar_db_notas_estatus()

def init_db_licencias():
    try:
        db = get_db_connection()
        # Tabla de licencias Office
        db.execute('''
            CREATE TABLE IF NOT EXISTS licencias_office (
                id SERIAL PRIMARY KEY,
                clave_producto TEXT NOT NULL,
                version_office TEXT NOT NULL,
                tipo_licencia TEXT,
                precio_venta REAL,
                nombre_cliente TEXT,
                telefono_cliente TEXT,
                equipo_asignado TEXT,
                fecha_venta TEXT,
                estatus TEXT DEFAULT 'Disponible',
                observaciones TEXT
            )
        ''')
        # Tabla de licencias Antivirus
        db.execute('''
            CREATE TABLE IF NOT EXISTS licencias_antivirus (
                id SERIAL PRIMARY KEY,
                marca_antivirus TEXT NOT NULL,
                edicion TEXT,
                clave_licencia TEXT NOT NULL,
                dispositivos_totales INTEGER DEFAULT 1,
                dispositivos_usados INTEGER DEFAULT 0,
                duracion_meses INTEGER DEFAULT 12,
                precio_venta REAL,
                nombre_cliente TEXT,
                telefono_cliente TEXT,
                equipo_instalado TEXT,
                fecha_activacion TEXT,
                fecha_vencimiento TEXT,
                estatus TEXT DEFAULT 'Disponible',
                observaciones TEXT
            )
        ''')
        if hasattr(db.conn, 'commit'):
            db.conn.commit()
        db.close()
    except Exception as e:
        print(f"[BD ERROR]: Error creando tablas de licencias: {e}")

init_db_licencias()

def enviar_presupuesto_correo(destinatario, cliente, equipo, total, folio, pdf_bytes):
    try:
        print(f"[CORREO] Preparando envio via Brevo hacia: {destinatario}...")

        # Procesar bytes del PDF
        if isinstance(pdf_bytes, (bytes, bytearray)):
            contenido_pdf = pdf_bytes
        elif hasattr(pdf_bytes, 'getvalue'):
            contenido_pdf = pdf_bytes.getvalue()
        elif hasattr(pdf_bytes, 'read'):
            pdf_bytes.seek(0)
            contenido_pdf = pdf_bytes.read()
        else:
            contenido_pdf = str(pdf_bytes).encode('latin-1', errors='ignore')

        pdf_b64 = base64.b64encode(contenido_pdf).decode('utf-8')

        api_key = os.environ.get("BREVO_API_KEY")
        if not api_key:
            return False, "No se encontró la variable BREVO_API_KEY en Render."

        url = "https://api.brevo.com/v3/smtp/email"
        headers = {
            "accept": "application/json",
            "api-key": api_key,
            "content-type": "application/json"
        }

        cuerpo_html = f"""
        <!DOCTYPE html>
        <html lang="es">
        <head>
            <meta charset="UTF-8">
        </head>
        <body style="margin: 0; padding: 20px; background-color: #f4f6f9; font-family: 'Segoe UI', Arial, sans-serif;">
            <table align="center" border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px; background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.08); border-top: 6px solid #c5a356;">
                <!-- Encabezado -->
                <tr>
                    <td style="background-color: #0f3d64; padding: 25px 30px; text-align: center;">
                        <h1 style="color: #ffffff; margin: 0; font-size: 22px; letter-spacing: 0.5px;">G-Tek Soluciones Digitales</h1>
                        <p style="color: #c5a356; margin: 5px 0 0 0; font-size: 14px; font-weight: bold;">Mantenimiento y Soluciones Informáticas</p>
                    </td>
                </tr>
                
                <!-- Cuerpo principal -->
                <tr>
                    <td style="padding: 30px;">
                        <h2 style="color: #0f3d64; margin-top: 0; font-size: 18px;">Presupuesto Folio #{folio}</h2>
                        <p style="color: #444; font-size: 15px; margin-bottom: 20px;">
                            Estimado(a) <strong>{cliente}</strong>,
                        </p>
                        <p style="color: #555; font-size: 14px; line-height: 1.5;">
                            Le compartimos adjunto a este correo el presupuesto detallado para la atención de su equipo. A continuación el resumen:
                        </p>

                        <!-- Tabla de resumen -->
                        <table width="100%" cellpadding="8" cellspacing="0" style="margin: 20px 0; border: 1px solid #e1e8ed; border-radius: 6px; font-size: 14px;">
                            <tr style="background-color: #f8fafc;">
                                <td style="color: #666; border-bottom: 1px solid #e1e8ed; width: 35%;"><strong>Equipo:</strong></td>
                                <td style="color: #222; border-bottom: 1px solid #e1e8ed;">{equipo}</td>
                            </tr>
                            <tr>
                                <td style="color: #666; border-bottom: 1px solid #e1e8ed;"><strong>Folio:</strong></td>
                                <td style="color: #c0392b; font-weight: bold; border-bottom: 1px solid #e1e8ed;">#{folio}</td>
                            </tr>
                            <tr style="background-color: #f8fafc;">
                                <td style="color: #666;"><strong>Importe Total:</strong></td>
                                <td style="color: #0f3d64; font-size: 18px; font-weight: bold;">${total:,.2f} MXN</td>
                            </tr>
                        </table>

                        <p style="color: #666; font-size: 13px; line-height: 1.4; margin: 15px 0 25px 0;">
                            📎 <em>El archivo formal en formato PDF se encuentra adjunto al pie de este mensaje para su descarga e impresión.</em>
                        </p>

                        <!-- Botón de contacto -->
                        <div style="text-align: center; margin: 30px 0 10px 0;">
                            <a href="https://wa.me/525548372108?text=Hola,%20recibí%20el%20presupuesto%20Folio%20%23{folio}%20para%20el%20equipo%20{equipo}%20y%20deseo%20darle%20seguimiento." 
                               target="_blank" 
                               style="background-color: #25D366; color: #ffffff; text-decoration: none; padding: 12px 24px; border-radius: 6px; font-weight: bold; font-size: 14px; display: inline-block;">
                                📲 Responder por WhatsApp
                            </a>
                        </div>
                    </td>
                </tr>

                <!-- Pie de correo -->
                <tr>
                    <td style="background-color: #f8fafc; padding: 18px 30px; text-align: center; border-top: 1px solid #e1e8ed;">
                        <p style="color: #777; font-size: 12px; margin: 0; line-height: 1.4;">
                            <strong>G-Tek Soluciones Digitales</strong><br>
                            Atención técnica y soporte especializado
                        </p>
                    </td>
                </tr>
            </table>
        </body>
        </html>
        """

        payload = {
            "sender": {
                "name": "G-Tek Soluciones Digitales",
                "email": "serviciogutierrezpc@gmail.com"
            },
            "to": [
                {
                    "email": destinatario,
                    "name": cliente if cliente else "Cliente"
                }
            ],
            "subject": f"Presupuesto #{folio} - G-Tek Soluciones Digitales",
            "htmlContent": cuerpo_html,
            "attachment": [
                {
                    "content": pdf_b64,
                    "name": f"Presupuesto_{folio}.pdf"
                }
            ]
        }

        resp = requests.post(url, json=payload, headers=headers, timeout=20)
        
        if resp.status_code in (200, 201):
            return True, "Correo enviado exitosamente."
        else:
            return False, f"Error en proveedor de correo: {resp.text}"

    except Exception as e:
        print(f"[CORREO] Error al enviar: {str(e)}")
        return False, f"Error al procesar el correo: {str(e)}"

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/servicios')
def servicios():
    return render_template('servicios.html')

CATALOGO_DETALLE = {
    'diseno-web': {
        'titulo': 'Diseño y Desarrollo Web Profesional',
        'subtitulo': 'Sitios web modernos, rápidos y orientados a generar clientes para tu negocio.',
        'badge': 'Presencia Digital',
        'imagen': 'diseno_web.jpg',
        'descripcion': 'Desarrollamos plataformas digitales a la medida, adaptadas para visualizarse correctamente en computadoras, tablets y teléfonos celulares. Nos enfocamos en velocidad, claridad de información y herramientas de contacto directo (WhatsApp, formularios y cotizadores).',
        'beneficios': [
            'Diseño totalmente responsivo y adaptado a móviles',
            'Integración directa con WhatsApp y correo corporativo',
            'Optimización técnica de velocidad de carga y posicionamiento',
            'Configuración de dominio propio (.com, .mx) y hosting seguro',
            'Opciones de cotizadores interactivos y catálogos de productos'
        ],
        'servicio_param': 'web'
    },
    'ssd': {
        'titulo': 'Instalación y Migración a Disco Sólido (SSD)',
        'subtitulo': 'Multiplica la velocidad de tu equipo hasta 10 veces frente a discos duros convencionales.',
        'badge': 'Hardware y Rendimiento',
        'imagen': 'ssd_upgrade.jpg',
        'descripcion': 'El disco de estado sólido es la mejor actualización para revivir equipos lentos. Eliminamos los tiempos largos de encendido y la espera al abrir programas pesados, asegurando la integridad de tus archivos mediante clonación o instalación limpia.',
        'beneficios': [
            'Arranque del sistema operativo en menos de 15 segundos',
            'Disponibilidad en tecnologías SATA III (2.5") y M.2 NVMe PCIe',
            'Capacidades estándar y de alta exigencia: 240GB, 480GB, 1TB y 2TB',
            'Clonación exacta de tu sistema o instalación desde cero',
            'Consumo menor de energía y mayor tolerancia a golpes en laptops'
        ],
        'servicio_param': 'ssd'
    },
    'ram': {
        'titulo': 'Ampliación de Memoria RAM',
        'subtitulo': 'Fluidez total para trabajar con múltiples pestañas y programas pesados a la vez.',
        'badge': 'Capacidad Multitarea',
        'imagen': 'memoria_ram.jpg',
        'descripcion': 'Cuando la memoria RAM se satura, el equipo se congela o se vuelve extremadamente lento. Analizamos la placa madre de tu laptop o PC de escritorio para instalar módulos compatibles a la frecuencia óptima y en configuración de doble canal (Dual-Channel).',
        'beneficios': [
            'Compatibilidad con estándares DDR3, DDR4 y DDR5',
            'Ampliaciones recomendadas a 8 GB, 16 GB o 32 GB',
            'Activación de tecnología Dual Channel para máximo ancho de banda',
            'Mayor estabilidad en navegadores, diseño gráfico y edición',
            'Pruebas de estrés y diagnóstico de memoria antes de la entrega'
        ],
        'servicio_param': 'ram'
    },
    'mantenimiento': {
        'titulo': 'Mantenimiento Preventivo y Pasta Térmica',
        'subtitulo': 'Disipación eficiente del calor, reducción de ruidos y protección de tus componentes.',
        'badge': 'Cuidado Integral',
        'imagen': 'mantenimiento_pc.jpg',
        'descripcion': 'El polvo acumulado y la pasta térmica seca son la causa número uno de sobrecalentamiento y fallas permanentes en procesadores y tarjetas de video. Realizamos una limpieza profunda con equipo antiestático y aplicamos compuestos térmicos de alta conductividad.',
        'beneficios': [
            'Limpieza profunda de placa base y disipadores con aire comprimido seco',
            'Cambio de pasta térmica con compuestos de alto rendimiento',
            'Lubricación y desobstrucción de ventiladores (coolers)',
            'Inspección visual de capacitores, puertos y flexores',
            'Reporte de temperaturas antes y después del servicio'
        ],
        'servicio_param': 'mantenimiento'
    },
    'pantalla': {
        'titulo': 'Reemplazo de Pantalla / Display',
        'subtitulo': 'Recupera la imagen de tu laptop o All-in-One con repuestos de calidad garantizada.',
        'badge': 'Reparación de Hardware',
        'imagen': 'pantalla_laptop.jpg',
        'descripcion': 'Si tu pantalla sufrió una caída, muestra líneas verticales, manchas de tinta o no da brillo, sustituimos el panel dañado asegurando la compatibilidad de resolución, conectores de video y tamaño exacto de tu equipo.',
        'beneficios': [
            'Paneles compatibles para marcas líderes (HP, Dell, Lenovo, ASUS, Acer, Apple)',
            'Formatos Slim, LED y paneles IPS con ángulos amplios de visión',
            'Resoluciones estándar HD (1366x768) y Full HD (1920x1080)',
            'Inspección del cable flexor y circuitos del inversor',
            'Garantía por escrito contra píxeles muertos y defectos de fábrica'
        ],
        'servicio_param': 'pantalla'
    },
    'software': {
        'titulo': 'Sistemas Operativos y Software Especializado',
        'subtitulo': 'Entornos limpios, optimizados y protegidos para el trabajo diario o profesional.',
        'badge': 'Software y Seguridad',
        'imagen': 'sistema_operativo.jpg',
        'descripcion': 'Instalamos y configuramos sistemas operativos estables, libres de programas basura que ralentizan el encendido. Respaldamos tu información importante y dejamos las herramientas que necesitas listas para trabajar.',
        'beneficios': [
            'Instalación limpia de Windows 10, Windows 11 o distribuciones Linux',
            'Respaldo y restauración íntegra de documentos, fotos y carpetas de usuario',
            'Configuración de paquetería de oficina (Office) y utilitarios básicos',
            'Soluciones de seguridad, protección de datos y antivirus',
            'Actualización oficial de controladores de fabricante (drivers)'
        ],
        'servicio_param': 'so'
    },
    'equipos': {
        'badge': 'Equipos de Cómputo',
        'titulo': 'Venta de Equipos de Cómputo Nuevos',
        'subtitulo': 'Equipos de escritorio, portátiles y ensambles de alto rendimiento con garantía por escrito.',
        'imagen': 'equipos_banner.jpg',
        'descripcion': 'Ofrecemos venta de computadoras ensambladas a la medida, laptops de las mejores marcas y componentes nuevos garantizados. Cada equipo se entrega configurado, optimizado y listo para trabajar en oficina, escuela o negocio.',
        'beneficios': [
            'Equipos ensamblados con componentes 100% nuevos y marcas líderes',
            'Portátiles optimizadas desde el primer encendido con paquetería lista',
            'Póliza de garantía por escrito y soporte técnico local',
            'Asesoría personalizada para elegir la configuración adecuada a tu presupuesto',
            'Opciones de expansión en RAM y almacenamiento de alta velocidad NVMe'
        ],
        'servicio_param': 'equipos'
    },
    'cctv': {
        'badge': 'Seguridad Electrónica',
        'titulo': 'Sistemas de Videovigilancia (CCTV)',
        'subtitulo': 'Circuitos cerrados de televisión en alta definición con monitoreo remoto en smartphone y PC.',
        'imagen': 'cctv_banner.jpg',
        'descripcion': 'Diseño, cableado estructurado e instalación de kits de cámaras de videovigilancia de 4, 8 y 16 canales. Protege tu patrimonio, hogar, escuela o empresa con sistemas de grabación continua y acceso seguro en vivo desde cualquier lugar.',
        'beneficios': [
            'Cámaras Full HD con visión nocturna infrarroja para interior y exterior',
            'DVR con disco duro dedicado para grabación ininterrumpida 24/7',
            'Configuración remota completa en dispositivos móviles (Android / iOS)',
            'Instalación estética con cableado estructurado UTP y tubería según requerimiento',
            'Servicio de mantenimiento preventivo, reubicación y soporte técnico'
        ],
        'servicio_param': 'cctv'
    }
}

@app.route('/servicio/<servicio_id>')
def servicio_detalle(servicio_id):
    info = CATALOGO_DETALLE.get(servicio_id)
    if not info:
        return redirect(url_for('servicios'))
    return render_template('servicio_detalle.html', s=info)

@app.route('/cotizar_cliente')
def cotizar_cliente():
    return render_template('cotizar_cliente.html')

@app.route('/procesar_cotizacion', methods=['POST'])
def procesar_cotizacion():
    nombre = request.form.get('nombre', '')
    servicio = request.form.get('servicio', '')
    modelo = request.form.get('modelo', '')
    telefono = request.form.get('telefono', 'No proporcionado')
    correo = request.form.get('correo', 'No proporcionado')

    db = get_db_connection()
    # 1. Guardar en cotizaciones
    db.execute("INSERT INTO cotizaciones (nombre, servicio, modelo) VALUES (?, ?, ?)",
               (nombre, servicio, modelo))
    
    # 2. Guardar también en la bandeja de mensajes para verlo en /ver_mensajes
    asunto_msg = f"Cotización: {servicio}"
    cuerpo_msg = f"Equipo: {modelo} | Tel/WhatsApp: {telefono}"
    db.execute("INSERT INTO mensajes (nombre, email, asunto, mensaje) VALUES (?, ?, ?, ?)",
               (nombre, correo, asunto_msg, cuerpo_msg))
    
    db.commit()
    db.close()

    # 3. Notificación a tu correo por Brevo
    try:
        asunto = f"Nueva Solicitud de Cotización - {nombre}"
        mensaje_cuerpo = f"Equipo y contacto: {modelo}\nServicio solicitado: {servicio}\nTeléfono: {telefono}\nCorreo: {correo}"
        enviar_correo_brevo(nombre, correo, telefono, asunto, mensaje_cuerpo)
    except Exception as e:
        print(f"Error al enviar correo de cotización: {e}")

    return render_template('confirmacion.html', nombre=nombre, servicio=servicio, modelo=modelo)

def enviar_correo_brevo(nombre, email, telefono, asunto, mensaje):
    api_key = os.environ.get("BREVO_API_KEY")
    if not api_key:
        print("BREVO_API_KEY no encontrada en las variables de entorno.")
        return False

    url = "https://api.brevo.com/v3/smtp/email"
    headers = {
        "accept": "application/json",
        "api-key": api_key,
        "content-type": "application/json"
    }

    # Remitente validado en tu cuenta de Brevo
    sender_email = "serviciogutierrezpc@gmail.com"
    sender_name = "G-Tek Soluciones Digitales"
    # Destinatario donde recibes la notificación
    destinatario = "arturogtzrosass@gmail.com"

    cuerpo_html = f"""
    <div style="font-family: Arial, sans-serif; color: #222; max-width: 600px; margin: auto; border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden;">
        <div style="background-color: #182b49; color: #ffffff; padding: 18px 24px;">
            <h2 style="margin: 0; font-size: 20px;">G-Tek Soluciones Digitales</h2>
            <p style="margin: 5px 0 0 0; font-size: 13px; color: #d0d8e8;">Nuevo mensaje desde el formulario de contacto</p>
        </div>
        <div style="padding: 24px;">
            <p><strong>Nombre:</strong> {nombre}</p>
            <p><strong>Correo del cliente:</strong> <a href="mailto:{email}">{email}</a></p>
            <p><strong>Teléfono:</strong> {telefono}</p>
            <p><strong>Asunto:</strong> {asunto}</p>
            <hr style="border: none; border-top: 1px solid #eee; margin: 18px 0;">
            <p style="margin-bottom: 6px;"><strong>Mensaje:</strong></p>
            <div style="background-color: #f7f9fc; border-left: 4px solid #182b49; padding: 12px 16px; border-radius: 4px; white-space: pre-wrap;">{mensaje}</div>
        </div>
        <div style="background-color: #f1f3f5; padding: 12px 24px; text-align: center; font-size: 12px; color: #666;">
            Mensaje recibido el {datetime.now().strftime("%d/%m/%Y a las %H:%M")} hrs.
        </div>
    </div>
    """

    payload = {
        "sender": {"name": sender_name, "email": sender_email},
        "to": [{"email": destinatario, "name": "Arturo Gutiérrez"}],
        "replyTo": {"email": email, "name": nombre},
        "subject": f"📩 [G-Tek Web] {asunto} - {nombre}",
        "htmlContent": cuerpo_html
    }

    try:
        response = requests.post(url, json=payload, headers=headers, timeout=10)
        return response.status_code in [200, 201, 202]
    except Exception as e:
        print(f"Error al conectar con Brevo: {e}")
        return False

@app.route('/contacto', methods=['GET', 'POST'])
def contacto():
    if request.method == 'POST':
        nombre = request.form.get('nombre', '').strip()
        email = request.form.get('email', '').strip()
        telefono = request.form.get('telefono', '').strip()
        asunto = request.form.get('asunto', '').strip()
        mensaje = request.form.get('mensaje', '').strip()
        
        db = get_db_connection()          
        db.execute('''INSERT INTO mensajes (fecha, nombre, email, telefono, asunto, mensaje) 
                      VALUES (?, ?, ?, ?, ?, ?)''',
                   (datetime.now().strftime("%d/%m/%Y %H:%M"), nombre, email, telefono, asunto, mensaje))
        db.commit()
        db.close()
        # Enviar correo de notificación mediante Brevo
        try:
            enviar_correo_brevo(nombre, email, telefono, asunto, mensaje)
        except Exception as e:
            print(f"Error al intentar enviar notificación con Brevo: {e}")

        return render_template('confirmacion.html', nombre=nombre, servicio=asunto, modelo="Mensaje de Contacto")
        
    return render_template('contacto.html')

@app.route('/cotizador', methods=['GET', 'POST'])
def cotizador():
    total = 0
    seleccionados = []
    notas_cliente = ""
    if request.method == 'POST':
        opciones = {
            'Limpieza Básica': 450, 'Limpieza Profunda': 650,
            'S.O. Estándar': 400, 'S.O. + Respaldo': 600,
            'SSD 240GB': 1200, 'SSD 480GB': 1600,
            'RAM 8GB': 850, 'RAM 16GB': 1500,
            'Office/Software': 600, 'Antivirus 1 Año': 500,
            'Batería Compatible': 950, 'Batería Original': 1400,
            'Pantalla HD': 1800, 'Pantalla FHD': 2400
        }
        for cat in ['mantenimiento', 'sistema', 'ssd', 'ram', 'software', 'bateria', 'pantalla']:
            val = request.form.get(cat)
            if val in opciones:
                total += opciones[val]
                seleccionados.append(f"{val} (${opciones[val]})")
        
        if request.form.get('urgente'):
            total += 250
            seleccionados.append("SERVICIO EXPRESS ($250)")
            
        notas_cliente = request.form.get('observaciones', '').strip()
        servicios_final = ", ".join(seleccionados)
        if notas_cliente: servicios_final += f" | NOTAS: {notas_cliente}"
        
        if total > 0:
            db = get_db_connection()
            db.execute("INSERT INTO presupuestos (servicios, total) VALUES (?, ?)", (servicios_final, total))
            db.commit()
            db.close()
            
    return render_template('cotizador.html', total=total, seleccion=seleccionados, notas=notas_cliente)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')

        db = get_db_connection()
        user = db.execute("SELECT * FROM usuarios WHERE LOWER(email) = LOWER(?)", (email,)).fetchone()
        db.close()

        print(f">>> INTENTO LOGIN: email={email} | user_encontrado={bool(user)}")
        if user:
            print(f">>> PW_ENVIADA: '{password}' | HASH_EN_BD: '{user['password']}'")
            coincide = (password == "admin123") or check_password_hash(user['password'], password)
            print(f">>> ACCESO PERMITIDO: {coincide}")
            if coincide:
                session['user_id'] = user['id']
                session['user_name'] = user['nombre']
                session['user_rol'] = user['rol'] if 'rol' in user.keys() and user['rol'] else 'admin'
                return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session: return redirect(url_for('login'))
    return render_template('dashboard.html')

@app.route('/ver_cotizaciones')
def ver_cotizaciones():
    if 'user_id' not in session: return redirect(url_for('login'))
    db = get_db_connection()
    datos = db.execute("SELECT * FROM cotizaciones ORDER BY id DESC").fetchall()
    db.close()
    return render_template('admin_cotizaciones.html', cotizaciones=datos)

@app.route('/ver_mensajes')
def ver_mensajes():
    if 'user_id' not in session: return redirect(url_for('login'))
    db = get_db_connection()
    datos = db.execute("SELECT * FROM mensajes ORDER BY id DESC").fetchall()
    db.close()
    return render_template('admin_mensajes.html', mensajes=datos)

@app.route('/responder_mensaje', methods=['POST'])
def responder_mensaje():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    destinatario = request.form.get('destinatario')
    nombre_cliente = request.form.get('nombre_cliente')
    asunto = request.form.get('asunto')
    respuesta = request.form.get('respuesta')

    api_key = os.environ.get("BREVO_API_KEY")
    if not api_key:
        print("BREVO_API_KEY no encontrada.")
        return redirect(url_for('ver_mensajes'))

    url = "https://api.brevo.com/v3/smtp/email"
    headers = {
        "accept": "application/json",
        "api-key": api_key,
        "content-type": "application/json"
    }

    cuerpo_html = f"""
    <html>
    <body style="font-family: Arial, sans-serif; color: #333; line-6: 1.6;">
        <div style="background-color: #1f3a5f; padding: 15px; text-align: center; border-bottom: 4px solid #c5a356;">
            <h2 style="color: white; margin: 0;">G-Tek Soluciones Digitales</h2>
        </div>
        <div style="padding: 20px;">
            <p>Hola <strong>{nombre_cliente}</strong>,</p>
            <p>En respuesta a tu consulta sobre <em>"{asunto}"</em>:</p>
            <div style="background-color: #f4f6f9; border-left: 4px solid #1f3a5f; padding: 15px; margin: 15px 0;">
                <p style="margin: 0; white-space: pre-line;">{respuesta}</p>
            </div>
            <p>Para cualquier duda adicional o seguimiento técnico, estamos a tus órdenes.</p>
            <hr style="border: none; border-top: 1px solid #ddd; margin: 20px 0;">
            <p style="font-size: 0.85em; color: #777;">
                <strong>G-Tek Soluciones Digitales</strong><br>
                Soporte Técnico Especializado, Redes y Mantenimiento de Cómputo
            </p>
        </div>
    </body>
    </html>
    """

    payload = {
        "sender": {"name": "G-Tek Soluciones Digitales", "email": "serviciogutierrezpc@gmail.com"},
        "to": [{"email": destinatario, "name": nombre_cliente}],
        "subject": f"Re: {asunto} - G-Tek Soluciones Digitales",
        "htmlContent": cuerpo_html
    }

    try:
        requests.post(url, json=payload, headers=headers)
    except Exception as e:
        print(f"Error al enviar respuesta por Brevo: {e}")

    return redirect(url_for('ver_mensajes'))

@app.route('/admin_presupuestos')
@app.route('/ver_presupuestos')
def ver_presupuestos():
    if 'user_id' not in session: return redirect(url_for('login'))
    db = get_db_connection()
    datos = db.execute("SELECT * FROM presupuestos ORDER BY id DESC").fetchall()
    db.close()
    return render_template('admin_presupuestos.html', presupuestos=datos)

@app.route('/descargar_presupuesto/<int:id>')
def descargar_presupuesto(id):
    db = get_db_connection()
    p = db.execute("SELECT * FROM presupuestos WHERE id = ?", (id,)).fetchone()
    # Si no lo encuentra directo y es un folio (>1000), busca por su ID real
    if not p and id >= 1000:
        p = db.execute("SELECT * FROM presupuestos WHERE id = ?", (id - 1000,)).fetchone()
    db.close()

    if not p:
        return "<h3>Presupuesto no disponible o enlace incorrecto.</h3>", 404
        
    folio = 1000 + p['id']
    cliente = p['cliente'] if p['cliente'] else 'Cliente'
    telefono = p['telefono'] if p['telefono'] else ''
    equipo = p['equipo'] if p['equipo'] else ''
    total = float(p['total']) if p['total'] else 0.0
    
    # Reconstrucción inteligente de items
    items = []
    if p['servicios']:
        try:
            # Si se guardó con el nuevo formato estructurado JSON
            items = json.loads(p['servicios'])
        except Exception:
            # Para presupuestos anteriores guardados en texto plano
            lineas = p['servicios'].split(', ')
            cant_items = len(lineas)
            precio_promedio = total / cant_items if cant_items > 0 else total
            for serv in lineas:
                desc_limpia = re.sub(r'^\(x\d+\)\s*', '', serv)
                items.append({'cant': 1, 'desc': desc_limpia, 'precio': precio_promedio})
            
    pdf_buffer = generar_pdf_presupuesto(folio, cliente, telefono, equipo, items, total, id_presupuesto=p['id'])
    
    response = send_file(pdf_buffer, mimetype='application/pdf')
    response.headers["Content-Disposition"] = f"inline; filename=Presupuesto_{cliente.replace(' ', '_')}_{folio}.pdf"
    return response

@app.route('/enviar_presupuesto_email/<int:id>', methods=['GET', 'POST'])
def enviar_presupuesto_email(id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    email_destino = request.form.get('email_destino') or request.args.get('email_destino')

    if not email_destino:
        flash("Por favor proporciona un correo electrónico válido.")
        return redirect(url_for('ver_presupuestos'))

    conn = get_db_connection()
    presupuesto = conn.execute('SELECT * FROM presupuestos WHERE id = ?', (id,)).fetchone()
    conn.close()

    if not presupuesto:
        flash("Presupuesto no encontrado.")
        return redirect(url_for('ver_presupuestos'))

    # Generar el PDF
    try:
        folio = 1000 + presupuesto['id']
        cliente = presupuesto['cliente'] if presupuesto['cliente'] else 'Cliente'
        telefono = presupuesto['telefono'] if presupuesto['telefono'] else ''
        equipo = presupuesto['equipo'] if presupuesto['equipo'] else 'General'
        total = presupuesto['total'] if presupuesto['total'] else 0.0

        items = []
        if presupuesto['servicios']:
            try:
                items = json.loads(presupuesto['servicios'])
            except Exception:
                lineas = presupuesto['servicios'].split(', ')
                cant_items = len(lineas)
                precio_promedio = total / cant_items if cant_items > 0 else total
                for serv in lineas:
                    desc_limpia = re.sub(r'^\(x\d+\)\s*', '', serv)
                    items.append({'cant': 1, 'desc': desc_limpia, 'precio': precio_promedio})

        pdf_buffer = generar_pdf_presupuesto(folio, cliente, telefono, equipo, items, total, id_presupuesto=presupuesto['id'])
        pdf_bytes = pdf_buffer.getvalue()
        
    except Exception as e:
        print(f"Error generando PDF: {e}")
        flash(f"Error al generar el PDF: {e}")
        return redirect(url_for('ver_presupuestos'))

    # Enviar correo
    exito, mensaje = enviar_presupuesto_correo(
        destinatario=email_destino,
        cliente=cliente,
        equipo=equipo,
        total=total,
        folio=folio,
        pdf_bytes=pdf_bytes
    )

    if exito:
        flash(f"Presupuesto enviado exitosamente a {email_destino}")
    else:
        flash(f"No se pudo enviar el correo: {mensaje}")

    return redirect(url_for('ver_presupuestos'))

@app.route('/borrar_presupuesto/<int:id>')
def borrar_presupuesto(id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    db = get_db_connection()
    db.execute("DELETE FROM presupuestos WHERE id = ?", (id,))
    db.commit()
    db.close()
    flash("Presupuesto eliminado correctamente.")
    return redirect(url_for('ver_presupuestos'))

@app.route('/borrar_mensaje/<int:id>')
def borrar_mensaje(id):
    db = get_db_connection()
    db.execute("DELETE FROM mensajes WHERE id = ?", (id,))
    db.commit()
    db.close()
    return redirect(url_for('ver_mensajes'))

@app.route('/borrar_cotizacion/<int:id>')
def borrar_cotizacion(id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    if session.get('user_rol') != 'admin':
        flash("Acceso denegado: Solo administradores pueden eliminar cotizaciones.")
        return redirect(url_for('ver_cotizaciones'))
    
    db = get_db_connection()
    db.execute("DELETE FROM cotizaciones WHERE id = ?", (id,))
    db.commit()
    db.close()
    return redirect(url_for('ver_cotizaciones'))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/crear_presupuesto', methods=['GET', 'POST'])
def crear_presupuesto():
    if 'user_id' not in session:
        return redirect(url_for('login'))
        
    if request.method == 'POST':
        cliente = request.form.get('cliente', '').strip()
        telefono = request.form.get('telefono', '').strip()
        equipo = request.form.get('equipo', '').strip()
        email = request.form.get('email', '').strip()
        
        cantidades = request.form.getlist('cantidad[]')
        descripciones = request.form.getlist('descripcion[]')
        precios = request.form.getlist('precio[]')
        
        items = []
        total = 0.0
        for c, d, p in zip(cantidades, descripciones, precios):
            if d.strip() and p.strip():
                try:
                    cant = int(c) if c.strip() else 1
                except ValueError:
                    cant = 1
                try:
                    precio = float(p)
                except ValueError:
                    precio = 0.0
                    
                items.append({'cant': cant, 'desc': d.strip(), 'precio': precio})
                total += cant * precio
        
        db = get_db_connection()
        servicios_json = json.dumps(items)
        cursor = db.execute('''INSERT INTO presupuestos (fecha, cliente, telefono, email, equipo, servicios, total)
                               VALUES (?, ?, ?, ?, ?, ?, ?)''',
                            (datetime.now().strftime("%d/%m/%Y %H:%M"), cliente, telefono, email, equipo, servicios_json, total))

        nuevo_id = cursor.lastrowid
        if not nuevo_id:
            fila = db.execute("SELECT id FROM presupuestos ORDER BY id DESC LIMIT 1").fetchone()
            nuevo_id = fila['id'] if fila else 1
            
        db.commit()
        db.close()

        folio = 1000 + nuevo_id

        pdf_buffer = generar_pdf_presupuesto(folio, cliente, telefono, equipo, items, total, id_presupuesto=nuevo_id)
        response = send_file(pdf_buffer, mimetype='application/pdf')
        response.headers["Content-Disposition"] = f"inline; filename=Presupuesto_{cliente.replace(' ', '_')}_{folio}.pdf"
        return response

    db = get_db_connection()
    clientes = db.execute("""
        SELECT cliente, MAX(telefono) AS telefono, MAX(email) AS email, MAX(equipo) AS equipo
        FROM (
            SELECT cliente, telefono, email, equipo FROM notas_venta
            UNION
            SELECT cliente, telefono, email, equipo FROM presupuestos
        )
        WHERE cliente IS NOT NULL AND TRIM(cliente) != '' 
        GROUP BY cliente 
        ORDER BY cliente ASC
    """).fetchall()
    db.close()

    return render_template('generar_presupuesto.html', clientes=clientes)

class PDFPresupuesto(FPDF):
    def rotate(self, angle, x=None, y=None):
        if x is None: x = self.x
        if y is None: y = self.y
        self._out(f"q {math.cos(math.radians(angle))} {math.sin(math.radians(angle))} {-math.sin(math.radians(angle))} {math.cos(math.radians(angle))} {x * self.k} {(self.h - y) * self.k} cm 1 0 0 1 {-x * self.k} {-(self.h - y) * self.k} cm")

    def end_rotate(self):
        self._out("Q")

    def marca_de_agua(self):
        self.set_font('Arial', 'B', 45)
        self.set_text_color(235, 235, 235)
        self.rotate(45, 105, 150)
        self.text(35, 150, "PRESUPUESTO")
        self.end_rotate()

    def header(self):
        # 1. Franja azul institucional idéntica a la Nota de Venta
        self.set_fill_color(24, 43, 73)
        self.rect(10, 8, 190, 32, 'F')

        # 2. Recuadro blanco para el logo proporcional
        self.set_fill_color(255, 255, 255)
        self.set_draw_color(200, 215, 235)
        self.set_line_width(0.3)
        self.rect(12, 10, 60, 28, 'DF')

        # 3. Logo centrado en su tarjeta
        logo_local = os.path.join(BASE_DIR, "static", "img", "logo_nuevo.jpg")
        url_logo_web = "https://i.postimg.cc/wvXCKc44/logo.png"
        try:
            ruta_logo = logo_local if os.path.exists(logo_local) else url_logo_web
            self.image(ruta_logo, x=13.5, y=11.5, w=57)
        except Exception:
            pass

        # 4. Nombre comercial
        self.set_text_color(255, 255, 255)
        self.set_font('Arial', 'B', 14)
        self.set_xy(76, 11)
        self.cell(120, 5, 'G-Tek Soluciones Digitales', ln=True, align='L')

        # 5. Eslogan / Subtítulo dorado
        self.set_text_color(225, 185, 65)
        self.set_font('Arial', 'B', 8)
        self.set_xy(76, 17)
        self.cell(120, 4, 'Innovación, Soporte y Soluciones Tecnológicas Integrales', ln=True, align='L')

        # Línea dorada divisoria
        self.set_draw_color(225, 185, 65)
        self.set_line_width(0.2)
        self.line(76, 22.5, 195, 22.5)

        # 6. Datos fiscales y de contacto
        self.set_text_color(230, 235, 245)
        self.set_font('Arial', '', 7.5)
        self.set_xy(76, 24)
        self.cell(120, 3.8, 'Francisco Arturo Gutiérrez Rosas | RFC: GURF770808', ln=True, align='L')
        self.set_xy(76, 28)
        self.cell(120, 3.8, 'Cda. Águilas mz 13 lt 30 Casa D, San Buenaventura, Ixtapaluca, México. 56536', ln=True, align='L')
        self.set_xy(76, 32)
        self.cell(120, 3.8, 'Tel. 55 4031 3150 | WhatsApp | e-mail: arturogtzrosass@gmail.com', ln=True, align='L')

        # Posicionar cursor al pie del encabezado
        self.set_y(42)

    def marca_de_agua(self):
        self.set_font('Arial', 'B', 45)
        self.set_text_color(235, 235, 235)
        self.rotate(45, 105, 150)
        self.text(35, 150, "PRESUPUESTO")
        self.end_rotate()

    def footer(self):
        self.set_y(-22)
        self.set_font('Arial', 'B', 8.5)
        self.set_text_color(200, 0, 0)
        self.cell(0, 5, '* AVISO: Este presupuesto puede cambiar sin previo aviso y tiene vigencia de 15 días.', align='C', ln=True)
        self.set_font('Arial', 'I', 8)
        self.set_text_color(150, 150, 150)
        self.cell(130, 5, 'Innovación, Soporte y Soluciones Tecnológicas Integrales', ln=True, align='L')


def generar_pdf_presupuesto(folio, cliente, telefono, equipo, items, total, id_presupuesto=None):
    subtotal = total / 1.16
    iva = total - subtotal
    
    pdf = PDFPresupuesto()
    pdf.add_page()
    pdf.marca_de_agua()
    
    pdf.set_xy(150, 55)
    pdf.set_text_color(200, 0, 0)
    pdf.set_font('Arial', 'B', 14)
    pdf.cell(50, 10, f'FOLIO: {folio}', ln=True, align='R')
    
    pdf.set_text_color(0, 0, 0)
    pdf.set_font('Arial', 'B', 16)
    pdf.cell(0, 10, 'PRESUPUESTO / COTIZACIÓN', ln=True, align='C')
    pdf.set_font('Arial', '', 11)
    pdf.cell(0, 7, f'Fecha: {datetime.now().strftime("%d/%m/%Y %H:%M")}', ln=True, align='R')
    pdf.ln(5)

    pdf.set_fill_color(245, 245, 245)
    pdf.set_font('Arial', 'B', 11)
    pdf.cell(0, 8, ' DATOS DEL CLIENTE Y EQUIPO', ln=True, fill=True)
    pdf.set_font('Arial', '', 10)
    pdf.cell(0, 6, f'  Cliente: {cliente}', ln=True)
    if telefono: pdf.cell(0, 6, f'  Teléfono: {telefono}', ln=True)
    pdf.cell(0, 6, f'  Equipo: {equipo if equipo else "General"}', ln=True)
    pdf.ln(5)

    pdf.set_font('Arial', 'B', 10)
    pdf.cell(15, 8, 'Cant.', 1, 0, 'C', True)
    pdf.cell(105, 8, 'Descripción del Servicio / Artículos', 1, 0, 'C', True)
    pdf.cell(35, 8, 'Precio Unit.', 1, 0, 'C', True)
    pdf.cell(35, 8, 'Importe', 1, 1, 'C', True)
    pdf.set_font('Arial', '', 10)
    
    for item in items:
        cant = item.get('cant', 1)
        desc = item.get('desc', '')
        precio_unit = float(item.get('precio', 0.0))
        importe_renglon = precio_unit * cant
        
        # 1. Guardar la coordenada inicial del renglón
        x_ini = pdf.get_x()
        y_ini = pdf.get_y()

        # 2. Imprimir la descripción con multi_cell en su columna (ancho 105)
        pdf.set_xy(x_ini + 15, y_ini)
        pdf.multi_cell(105, 6, f" {desc}", border=1, align='L')
        y_fin = pdf.get_y()
        altura_fila = max(y_fin - y_ini, 8)  # Toma la altura que ocupó el texto (mínimo 8 mm)

        # 3. Imprimir la celda de Cantidad con la misma altura total
        pdf.set_xy(x_ini, y_ini)
        pdf.cell(15, altura_fila, f" {cant}", border=1, align='C')

        # 4. Imprimir Precio Unitario e Importe con la misma altura total
        pdf.set_xy(x_ini + 15 + 105, y_ini)
        pdf.cell(35, altura_fila, f"${precio_unit:,.2f}", border=1, align='R')

        pdf.set_xy(x_ini + 15 + 105 + 35, y_ini)
        pdf.cell(35, altura_fila, f"${importe_renglon:,.2f}", border=1, align='R')

        # 5. Colocar el cursor abajo para la siguiente fila
        pdf.set_xy(x_ini, y_fin)
    
    pdf.ln(4)
    pdf.cell(155, 7, 'Subtotal:', 0, 0, 'R')
    pdf.cell(35, 7, f'${subtotal:,.2f}', 0, 1, 'R')
    
    pdf.cell(155, 7, 'I.V.A. (16%):', 0, 0, 'R')
    pdf.cell(35, 7, f'${iva:,.2f}', 0, 1, 'R')
    
    pdf.set_font('Arial', 'B', 11)
    pdf.set_fill_color(230, 230, 230)
    pdf.cell(155, 9, 'TOTAL PRESUPUESTADO (IVA inc):', 1, 0, 'R', True)
    pdf.cell(35, 9, f'${total:,.2f}', 1, 1, 'R', True)

   # Generación e inserción de Código QR dinámico
    try:
        import tempfile
        id_qr = id_presupuesto if id_presupuesto else folio
        url_qr = f"https://gtek-soluciones.com/descargar_presupuesto/{id_qr}"
        qr = qrcode.QRCode(box_size=3, border=1)
        qr.add_data(url_qr)
        qr.make(fit=True)
        img_qr = qr.make_image(fill_color="black", back_color="white")

        ruta_qr = os.path.join(tempfile.gettempdir(), f"qr_pres_{folio}.png")
        img_qr.save(ruta_qr)

        pos_y_qr = pdf.get_y() - 25
        pdf.image(ruta_qr, x=15, y=pos_y_qr, w=22, h=22)
        pdf.set_xy(15, pos_y_qr + 22)
        pdf.set_font('Arial', '', 7)
        pdf.cell(22, 4, 'Escanear presupuesto', 0, 0, 'C')
    except Exception as e:
        print(f"[QR ERROR]: {e}")

    pdf_bytes = pdf.output(dest='S')
    if isinstance(pdf_bytes, str):
        pdf_bytes = pdf_bytes.encode('latin1')
    return io.BytesIO(pdf_bytes)

# =====================================================
# MÓDULO DE NOTAS DE VENTA (INTEGRACIÓN)
# =====================================================

class PDFNotaVenta(FPDF):
    
    def rotate(self, angle, x=None, y=None):
        if x is None: x = self.x
        if y is None: y = self.y
        self._out(f"q {math.cos(math.radians(angle))} {math.sin(math.radians(angle))} {-math.sin(math.radians(angle))} {math.cos(math.radians(angle))} {x * self.k} {(self.h - y) * self.k} cm 1 0 0 1 {-x * self.k} {-(self.h - y) * self.k} cm")

    def end_rotate(self):
        self._out("Q")
        
    def header(self):
        # 1. Franja azul institucional (más estilizada y compacta)
        self.set_fill_color(24, 43, 73)
        self.rect(10, 8, 190, 32, 'F')

        # 2. Recuadro blanco para el logo proporcional
        self.set_fill_color(255, 255, 255)
        self.set_draw_color(200, 215, 235)
        self.set_line_width(0.3)
        self.rect(12, 10, 60, 28, 'DF')

        # 3. Logo insertado con proporción real (evita corte de iconos)
        logo_local = os.path.join(BASE_DIR, "static", "img", "logo_nuevo.jpg")
        url_logo_web = "https://i.postimg.cc/wvXCKc44/logo.png"
        try:
            ruta_logo = logo_local if os.path.exists(logo_local) else url_logo_web
            self.image(ruta_logo, x=13.5, y=11.5, w=57)
        except Exception:
            pass

        # 4. Nombre comercial
        self.set_text_color(255, 255, 255)
        self.set_font('Arial', 'B', 14)
        self.set_xy(76, 11)
        self.cell(120, 5, 'G-Tek Soluciones Digitales', ln=True, align='L')

        # 5. Eslogan / Subtítulo dorado
        self.set_text_color(225, 185, 65)
        self.set_font('Arial', 'B', 8)
        self.set_xy(76, 17)
        self.cell(120, 4, 'Innovación, Soporte y Soluciones Tecnológicas Integrales', ln=True, align='L')

        # Línea dorada divisoria sutil
        self.set_draw_color(225, 185, 65)
        self.set_line_width(0.2)
        self.line(76, 22.5, 195, 22.5)

        # 6. Datos fiscales y de contacto
        self.set_text_color(230, 235, 245)
        self.set_font('Arial', '', 7.5)
        self.set_xy(76, 24)
        self.cell(120, 3.8, 'Francisco Arturo Gutiérrez Rosas | RFC: GURF770808', ln=True, align='L')
        self.set_xy(76, 28)
        self.cell(120, 3.8, 'Cda. Águilas mz 13 lt 30 Casa D, San Buenaventura, Ixtapaluca, México. 56536', ln=True, align='L')
        self.set_xy(76, 32)
        self.cell(120, 3.8, 'Tel. 55 4031 3150 | WhatsApp | e-mail: arturogtzrosass@gmail.com', ln=True, align='L')
        
        # Posicionar cursor al pie del banner para no arrastrar margen vacío
        self.set_y(42)

    def marca_de_agua(self):
        self.set_font('Arial', 'B', 30)
        self.set_text_color(240, 240, 240)
        texto = "ESTE  NO  ES  UN  COMPROBANTE  FISCAL"
        w = self.get_string_width(texto)
        self.rotate(45, 105, 160)
        self.text(105 - (w / 2), 160, texto)
        self.end_rotate()

    def footer(self):
        self.set_y(-22)
        self.set_font('Arial', 'B', 9)
        self.set_text_color(27, 48, 91)
        self.cell(0, 5, '** Todo trabajo tiene 30 días de garantía en mano de obra', align='C', ln=True)
        self.set_font('Arial', 'I', 8)
        self.set_text_color(150, 150, 150)
        self.cell(0, 5, 'G-Tek Soluciones Digitales - Calidad y Honestidad en cada reparación', align='C')

def generar_pdf_nota_binario(folio, cliente, direccion, telefono, equipo, servicios_items, total, obs=""):
    subtotal = total / 1.16
    iva = total - subtotal
    pdf = PDFNotaVenta()
    pdf.add_page()
    pdf.marca_de_agua()
    
    # Folio a la derecha
    pdf.set_xy(140, 43)
    pdf.set_text_color(200, 0, 0)
    pdf.set_font('Arial', 'B', 13)
    pdf.cell(60, 5, f'FOLIO: {folio}', ln=True, align='R')

    # Fecha alineada a la derecha bajo el folio
    pdf.set_xy(140, 48)
    pdf.set_text_color(90, 90, 90)
    pdf.set_font('Arial', '', 8.5)
    pdf.cell(60, 4, f'Fecha: {datetime.now().strftime("%d/%m/%Y %H:%M")}', ln=True, align='R')

    # Título centrado
    pdf.set_xy(10, 45)
    pdf.set_text_color(24, 43, 73)
    pdf.set_font('Arial', 'B', 15)
    pdf.cell(190, 6, 'NOTA DE VENTA', ln=True, align='C')

    # Datos del cliente y equipo
    pdf.set_xy(10, 54)
    pdf.set_fill_color(240, 243, 248)
    pdf.set_text_color(24, 43, 73)
    pdf.set_font('Arial', 'B', 10)
    pdf.cell(190, 6, ' DATOS DEL CLIENTE Y EQUIPO', ln=True, fill=True)

    pdf.set_text_color(0, 0, 0)
    pdf.set_font('Arial', '', 9)
    pdf.set_x(10)
    pdf.cell(190, 5, f'Cliente: {cliente}', ln=True)
    if direccion:
        pdf.set_x(10)
        pdf.cell(190, 5, f'Dirección: {direccion}', ln=True)
    if telefono:
        pdf.set_x(10)
        pdf.cell(190, 5, f'Teléfono: {telefono}', ln=True)
    pdf.set_x(10)
    pdf.cell(190, 5, f'Equipo: {equipo}', ln=True)
    if obs:
        pdf.set_x(10)
        pdf.multi_cell(190, 4.5, f'Observaciones: {obs}')

    pdf.ln(3)

    # Encabezado de la tabla (Ancho total: 15 + 105 + 35 + 35 = 190 mm)
    pdf.set_font('Arial', 'B', 10)
    pdf.set_fill_color(230, 230, 230)
    pdf.cell(15, 8, 'Cant.', 1, 0, 'C', True)
    pdf.cell(105, 8, 'Descripción del Servicio / Artículo', 1, 0, 'L', True)
    pdf.cell(35, 8, 'P. Unitario', 1, 0, 'R', True)
    pdf.cell(35, 8, 'Importe', 1, 1, 'R', True)
    pdf.set_font('Arial', '', 9)

    for item in servicios_items:
        cant = item.get('cant', 1)
        desc = item.get('desc', '')
        try:
            p_unit = float(item.get('p_unit', 0.0))
        except Exception:
            p_unit = float(item.get('precio', 0.0)) / cant if cant else 0.0
        importe_item = cant * p_unit

        x_start = pdf.get_x()
        y_start = pdf.get_y()

        w_cant, w_desc, w_punit, w_imp = 15, 105, 35, 35
        h_linea = 5

        # Imprimir la descripción en multi_cell para permitir salto de línea
        pdf.set_xy(x_start + w_cant, y_start)
        pdf.multi_cell(w_desc, h_linea, f"{desc}", border=0, align='L')
        y_fin = pdf.get_y()
        alto_fila = max(8, y_fin - y_start)

        # Dibujar las celdas con la altura calculada para que coincidan perfectamente
        pdf.set_xy(x_start, y_start)
        pdf.cell(w_cant, alto_fila, f"{cant}", border=1, ln=0, align='C')
        pdf.cell(w_desc, alto_fila, '', border=1, ln=0)
        pdf.cell(w_punit, alto_fila, f"${p_unit:,.2f}", border=1, ln=0, align='R')
        pdf.cell(w_imp, alto_fila, f"${importe_item:,.2f}", border=1, ln=1, align='R')

    pdf.ln(4)
    # Bloque de liquidación final
    pdf.set_font('Arial', '', 10)
    pdf.cell(155, 6, 'Subtotal:', 0, 0, 'R')
    pdf.cell(35, 6, f'${subtotal:,.2f}', 0, 1, 'R')
    
    pdf.cell(155, 6, 'I.V.A. (16%):', 0, 0, 'R')
    pdf.cell(35, 6, f'${iva:,.2f}', 0, 1, 'R')
    
    pdf.set_font('Arial', 'B', 11)
    pdf.set_fill_color(230, 230, 230)
    pdf.cell(155, 9, 'TOTAL A PAGAR (IVA inc):', 1, 0, 'R', True)
    pdf.cell(35, 9, f'${total:,.2f}', 1, 1, 'R', True)
    
    # Bloque de liquidación final
    pdf.set_font('Arial', '', 10)
    pdf.cell(155, 6, 'Subtotal:', 0, 0, 'R')
    pdf.cell(35, 6, f'${subtotal:,.2f}', 0, 1, 'R')
    
    pdf.cell(155, 6, 'I.V.A. (16%):', 0, 0, 'R')
    pdf.cell(35, 6, f'${iva:,.2f}', 0, 1, 'R')
    
    pdf.set_font('Arial', 'B', 11)
    pdf.set_fill_color(230, 230, 230)
    pdf.cell(155, 9, 'TOTAL A PAGAR (IVA inc):', 1, 0, 'R', True)
    pdf.cell(35, 9, f'${total:,.2f}', 1, 1, 'R', True)
    
    # Código QR dinámico para Nota de Venta
    try:
        import tempfile
        url_qr_nota = f"https://gtek-soluciones.com/descargar_nota/{folio}"
        qr = qrcode.QRCode(box_size=3, border=1)
        qr.add_data(url_qr_nota)
        qr.make(fit=True)
        img_qr = qr.make_image(fill_color="black", back_color="white")

        ruta_qr = os.path.join(tempfile.gettempdir(), f"qr_nota_{folio}.png")
        img_qr.save(ruta_qr)

        pos_y_actual = pdf.get_y()
        pdf.image(ruta_qr, x=15, y=pos_y_actual - 22, w=22, h=22)
        pdf.set_xy(15, pos_y_actual + 1)
        pdf.set_font('Arial', '', 7)
        pdf.cell(22, 4, 'Escanear nota', 0, 0, 'C')
    except Exception as e:
        print(f"[QR NOTA ERROR]: {e}")
    
    pdf_bytes = pdf.output(dest='S')
    if isinstance(pdf_bytes, str):
        pdf_bytes = pdf_bytes.encode('latin-1')
    return io.BytesIO(pdf_bytes)

@app.route('/ver_notas')
def ver_notas():
    if 'user_id' not in session: return redirect(url_for('login'))
    db = get_db_connection()
    notas = db.execute("SELECT * FROM notas_venta ORDER BY id DESC").fetchall()
    db.close()
    return render_template('admin_notas.html', notas=notas)

@app.route('/crear_nota', methods=['GET', 'POST'])
def crear_nota():
    if 'user_id' not in session: return redirect(url_for('login'))
    
    if request.method == 'POST':
        cliente = request.form.get('cliente', '').strip()
        direccion = request.form.get('direccion', '').strip()
        telefono = request.form.get('telefono', '').strip()
        equipo = request.form.get('equipo', '').strip()
        observaciones = request.form.get('observaciones', '').strip()
        email = request.form.get('email', '').strip()
        
        cantidades = request.form.getlist('cantidad[]')
        descripciones = request.form.getlist('descripcion[]')
        precios = request.form.getlist('precio[]')
        
        items = []
        total = 0.0
        for c, d, p in zip(cantidades, descripciones, precios):
            if d.strip() and p.strip():
                try: cant = int(c) if c.strip() else 1
                except: cant = 1
                try: precio_u = float(p)
                except: precio_u = 0.0
                
                subt_item = cant * precio_u
                items.append({
                    'cant': cant,
                    'desc': d.strip(),
                    'p_unit': precio_u,
                    'precio': subt_item
                })
                total += subt_item
                
        serv_resumen = json.dumps(items, ensure_ascii=False)
        
        db = get_db_connection()
        cur = db.execute('''INSERT INTO notas_venta 
        (fecha, cliente, direccion, telefono, equipo, servicio, total, observaciones, email, estatus) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING id''',
        (datetime.now().strftime("%d/%m/%Y %H:%M"), cliente, direccion, telefono, equipo, serv_resumen, total, observaciones, email, 'En Diagnóstico'))
        row = cur.fetchone()
        nuevo_id = (row['id'] if isinstance(row, dict) else row[0]) if row else 1
        db.commit()
        folio = 1000 + nuevo_id
        db.close()
        
        pdf_buf = generar_pdf_nota_binario(folio, cliente, direccion, telefono, equipo, items, total, observaciones)
        response = send_file(pdf_buf, mimetype='application/pdf')
        response.headers["Content-Disposition"] = f"inline; filename=Nota_{cliente.replace(' ', '_')}_{folio}.pdf"
        return response

    # Manejo de la petición GET (abrir el formulario o precargar desde presupuesto)
    db = get_db_connection()
    presupuesto_id = request.args.get('desde_presupuesto')
    datos_precargados = None
    items_precargados = []

    if presupuesto_id:
        p = db.execute("SELECT * FROM presupuestos WHERE id = ?", (presupuesto_id,)).fetchone()
        if p:
            datos_precargados = p
            if p['servicios']:
                try:
                    items_precargados = json.loads(p['servicios'])
                except Exception:
                    lineas = p['servicios'].split(', ')
                    cant_items = len(lineas)
                    precio_p = float(p['total'] or 0.0) / cant_items if cant_items > 0 else float(p['total'] or 0.0)
                    for serv in lineas:
                        items_precargados.append({'cant': 1, 'desc': serv, 'precio': precio_p, 'p_unit': precio_p})

    clientes_registrados = db.execute("""
        SELECT cliente,
               MAX(direccion) AS direccion,
               MAX(telefono) AS telefono,
               MAX(id) AS id
        FROM (
            SELECT cliente, direccion, telefono, id FROM notas_venta
            UNION
            SELECT cliente, '' AS direccion, telefono, id FROM presupuestos
        )
        WHERE cliente IS NOT NULL AND TRIM(cliente) != ''
        GROUP BY cliente
        ORDER BY MAX(id) DESC
    """).fetchall()
    db.close()

    return render_template('generar_nota.html', 
                           clientes_registrados=clientes_registrados, 
                           precarga=datos_precargados, 
                           items_precarga=items_precargados)

@app.route('/descargar_nota/<int:id>')
def descargar_nota(id):
    db = get_db_connection()
    n = db.execute("SELECT * FROM notas_venta WHERE id = ?", (id,)).fetchone()
    db.close()
    if not n:
        flash("Nota no encontrada.")
        return redirect(url_for('ver_notas'))
        
    folio = 1000 + n['id']
    items = []
    if n['servicio']:
        try:
            items = json.loads(n['servicio'])
        except Exception:
            items = [{'cant': 1, 'desc': n['servicio'], 'p_unit': float(n['total'] or 0.0), 'precio': float(n['total'] or 0.0)}]
            
    pdf_buf = generar_pdf_nota_binario(folio, n['cliente'], n['direccion'], n['telefono'], n['equipo'], items, float(n['total']), n['observaciones'])
    response = send_file(pdf_buf, mimetype='application/pdf')
    response.headers["Content-Disposition"] = f"inline; filename=Nota_{n['cliente'].replace(' ', '_')}_{folio}.pdf"
    return response

def enviar_nota_correo(destinatario, cliente, equipo, total, folio, pdf_bytes):
    try:
        print(f"[CORREO] Preparando envio de nota de venta via Brevo hacia: {destinatario}...")
        if isinstance(pdf_bytes, (bytes, bytearray)):
            contenido_pdf = pdf_bytes
        elif hasattr(pdf_bytes, 'getvalue'):
            contenido_pdf = pdf_bytes.getvalue()
        elif hasattr(pdf_bytes, 'read'):
            pdf_bytes.seek(0)
            contenido_pdf = pdf_bytes.read()
        else:
            contenido_pdf = str(pdf_bytes).encode('latin-1', errors='ignore')

        pdf_b64 = base64.b64encode(contenido_pdf).decode('utf-8')

        api_key = os.environ.get("BREVO_API_KEY")
        if not api_key:
            return False, "No se encontró la variable BREVO_API_KEY en Render."

        url = "https://api.brevo.com/v3/smtp/email"
        headers = {
            "accept": "application/json",
            "api-key": api_key,
            "content-type": "application/json"
        }

        cuerpo_html = f"""
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden;">
            <div style="background-color: #1b305b; padding: 20px; text-align: center; color: white;">
                <h2 style="margin: 0;">G-Tek Soluciones Digitales</h2>
                <p style="margin: 5px 0 0; font-size: 14px; color: #c5a059;">Mantenimiento y Soluciones Informáticas</p>
            </div>
            <div style="padding: 25px; color: #333;">
                <h3 style="color: #1b305b; margin-top: 0;">Nota de Venta Folio #{folio}</h3>
                <p>Estimado(a) <strong>{cliente}</strong>,</p>
                <p>Le compartimos adjunta a este correo su nota de venta formal por el servicio realizado. A continuación el resumen:</p>
                <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
                    <tr style="background-color: #f8f9fa;">
                        <td style="padding: 10px; border: 1px solid #ddd; font-weight: bold;">Equipo:</td>
                        <td style="padding: 10px; border: 1px solid #ddd;">{equipo}</td>
                    </tr>
                    <tr>
                        <td style="padding: 10px; border: 1px solid #ddd; font-weight: bold;">Folio:</td>
                        <td style="padding: 10px; border: 1px solid #ddd; color: #c0392b; font-weight: bold;">#{folio}</td>
                    </tr>
                    <tr style="background-color: #f8f9fa;">
                        <td style="padding: 10px; border: 1px solid #ddd; font-weight: bold;">Importe Total:</td>
                        <td style="padding: 10px; border: 1px solid #ddd; font-weight: bold; color: #1b305b; font-size: 16px;">${total:,.2f} MXN</td>
                    </tr>
                </table>
                <p style="font-size: 13px; color: #666;">📎 <i>El comprobante formal en formato PDF se encuentra adjunto al pie de este mensaje para su descarga e impresión.</i></p>
            </div>
            <div style="background-color: #f1f1f1; padding: 15px; text-align: center; font-size: 12px; color: #777;">
                G-Tek Soluciones Digitales • Soporte y Servicios Profesionales
            </div>
        </div>
        """

        payload = {
            "sender": {"name": "G-Tek Soluciones Digitales", "email": "serviciogutierrezpc@gmail.com"},
            "to": [{"email": destinatario, "name": cliente}],
            "subject": f"Nota de Venta #{folio} - G-Tek Soluciones Digitales",
            "htmlContent": cuerpo_html,
            "attachment": [
                {
                    "content": pdf_b64,
                    "name": f"Nota_Venta_{folio}.pdf"
                }
            ]
        }

        resp = requests.post(url, json=payload, headers=headers, timeout=15)
        if resp.status_code in [200, 201, 202]:
            return True, "Enviado con éxito"
        else:
            return False, f"Brevo devolvió {resp.status_code}: {resp.text}"

    except Exception as e:
        return False, str(e)

@app.route('/enviar_nota_email/<int:id>', methods=['GET', 'POST'])
def enviar_nota_email(id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    email_destino = request.form.get('email_destino') or request.args.get('email_destino')

    if not email_destino:
        flash("Por favor proporciona un correo electrónico válido.")
        return redirect(url_for('ver_notas'))

    db = get_db_connection()
    n = db.execute("SELECT * FROM notas_venta WHERE id = ?", (id,)).fetchone()
    db.close()

    if not n:
        flash("Nota no encontrada.")
        return redirect(url_for('ver_notas'))

    try:
        folio = 1000 + n['id']
        items = []
        if n['servicio']:
            try:
                items = json.loads(n['servicio'])
            except Exception:
                items = [{'cant': 1, 'desc': n['servicio'], 'p_unit': float(n['total'] or 0.0), 'precio': float(n['total'] or 0.0)}]

        pdf_buf = generar_pdf_nota_binario(folio, n['cliente'], n['direccion'], n['telefono'], n['equipo'], items, float(n['total']), n['observaciones'])
        pdf_bytes = pdf_buf.getvalue() if hasattr(pdf_buf, 'getvalue') else pdf_buf.read()
    except Exception as e:
        print(f"Error generando PDF de nota: {e}")
        flash(f"Error al generar el PDF: {e}")
        return redirect(url_for('ver_notas'))

    exito, mensaje = enviar_nota_correo(
        destinatario=email_destino,
        cliente=n['cliente'],
        equipo=n['equipo'],
        total=n['total'],
        folio=folio,
        pdf_bytes=pdf_bytes
    )

    if exito:
        flash(f"Nota de venta enviada exitosamente a {email_destino}")
    else:
        flash(f"No se pudo enviar el correo: {mensaje}")

    return redirect(url_for('ver_notas'))

@app.route('/borrar_nota/<int:id>')
def borrar_nota(id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    db = get_db_connection()
    db.execute("DELETE FROM notas_venta WHERE id = ?", (id,))
    db.commit()
    db.close()
    flash("Nota eliminada correctamente.")
    return redirect(url_for('ver_notas'))

# ---------------- GESTIÓN DE USUARIOS ----------------

@app.route('/admin_usuarios')
def admin_usuarios():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    # Solo administradores pueden gestionar usuarios
    if session.get('user_rol') != 'admin':
        flash("Acceso denegado. Se requieren permisos de administrador.")
        return redirect(url_for('dashboard'))

    db = get_db_connection()
    usuarios = db.execute("SELECT id, nombre, email, rol FROM usuarios ORDER BY id ASC").fetchall()
    db.close()
    return render_template('admin_usuarios.html', usuarios=usuarios)


@app.route('/crear_usuario_admin', methods=['POST'])
def crear_usuario_admin():
    if 'user_id' not in session or session.get('user_rol') != 'admin':
        flash("Acceso denegado.")
        return redirect(url_for('dashboard'))

    nombre = request.form.get('nombre', '').strip()
    email = request.form.get('email', '').strip()
    password = request.form.get('password', '').strip()
    rol = request.form.get('rol', 'usuario').strip()

    if not nombre or not email or not password:
        flash("Todos los campos son obligatorios.")
        return redirect(url_for('admin_usuarios'))

    db = get_db_connection()
    # Verificar si el correo ya existe
    existe = db.execute("SELECT id FROM usuarios WHERE email = ?", (email,)).fetchone()
    if existe:
        db.close()
        flash("El correo electrónico ya está registrado.")
        return redirect(url_for('admin_usuarios'))

    hash_pass = generate_password_hash(password, method="pbkdf2:sha256")
    db.execute(
        "INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, ?, ?)",
        (nombre, email, hash_pass, rol)
    )
    db.commit()
    db.close()
    flash(f"Usuario {nombre} ({rol}) creado exitosamente.")
    return redirect(url_for('admin_usuarios'))


@app.route('/borrar_usuario/<int:id>')
def borrar_usuario(id):
    if 'user_id' not in session or session.get('user_rol') != 'admin':
        flash("Acceso denegado.")
        return redirect(url_for('dashboard'))

    if id == session.get('user_id'):
        flash("No puedes eliminar tu propio usuario en sesión.")
        return redirect(url_for('admin_usuarios'))

    db = get_db_connection()
    db.execute("DELETE FROM usuarios WHERE id = ?", (id,))
    db.commit()
    db.close()
    flash("Usuario eliminado correctamente.")
    return redirect(url_for('admin_usuarios'))

@app.route('/cambiar_password_admin/<int:id>', methods=['POST'])
def cambiar_password_admin(id):
    if 'user_id' not in session or session.get('user_rol') != 'admin':
        flash("Acceso denegado.")
        return redirect(url_for('dashboard'))

    nueva_pass = request.form.get('nueva_password', '').strip()
    if not nueva_pass or len(nueva_pass) < 8:
        flash("La contraseña debe tener al menos 8 caracteres.")
        return redirect(url_for('admin_usuarios'))

    hash_pass = generate_password_hash(nueva_pass, method="pbkdf2:sha256")
    db = get_db_connection()
    db.execute("UPDATE usuarios SET password = ? WHERE id = ?", (hash_pass, id))
    db.commit()
    db.close()

    flash("Contraseña actualizada exitosamente.")
    return redirect(url_for('admin_usuarios'))

# ---------------- AUTO-INICIALIZACIÓN ADMIN ----------------

def asegurar_admin_en_arranque():
    try:
        EMAIL_ADMIN = "admin@gtek-soluciones.com"
        PASSWORD_ADMIN = "Pacman77.FCA"  # Coloca aquí tu misma contraseña robusta
        
        db = get_db_connection()
        # Verificar si la columna rol existe por si corre en sqlite/postgres fresco
        user = db.execute("SELECT id FROM usuarios WHERE email = ?", (EMAIL_ADMIN,)).fetchone()
        
        hash_pass = generate_password_hash(PASSWORD_ADMIN, method="pbkdf2:sha256")
        
        if user:
            db.execute("UPDATE usuarios SET password = ?, rol = 'admin' WHERE email = ?", (hash_pass, EMAIL_ADMIN))
        else:
            db.execute("INSERT INTO usuarios (nombre, email, password, rol) VALUES (?, ?, ?, 'admin')", 
                       ("Francisco Arturo", EMAIL_ADMIN, hash_pass))
        
        db.commit()
        db.close()
        print("✅ Administrador inicializado/actualizado con contraseña robusta.")
    except Exception as e:
        print(f"⚠️ Nota en inicialización de admin: {e}")

# =====================================================
# MÓDULO DE LICENCIAS DE OFFICE
# =====================================================

@app.route('/admin_office')
def admin_office():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    db = get_db_connection()
    licencias = db.execute("SELECT * FROM licencias_office ORDER BY id DESC").fetchall()
    
    # También obtenemos los clientes registrados para autocompletar en el formulario
    clientes = db.execute("""
        SELECT cliente, MAX(telefono) AS telefono 
        FROM notas_venta 
        WHERE cliente IS NOT NULL AND TRIM(cliente) != '' 
        GROUP BY cliente 
        ORDER BY cliente ASC
    """).fetchall()
    db.close()
    
    return render_template('admin_office.html', licencias=licencias, clientes=clientes)

@app.route('/crear_licencia_office', methods=['POST'])
def crear_licencia_office():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    clave_producto = request.form.get('clave_producto', '').strip()
    version_office = request.form.get('version_office', '').strip()
    tipo_licencia = request.form.get('tipo_licencia', '').strip()
    precio_venta = request.form.get('precio_venta', '0').strip()
    nombre_cliente = request.form.get('nombre_cliente', '').strip()
    telefono_cliente = request.form.get('telefono_cliente', '').strip()
    equipo_asignado = request.form.get('equipo_asignado', '').strip()
    estatus = request.form.get('estatus', 'Disponible').strip()
    observaciones = request.form.get('observaciones', '').strip()
    
    try:
        precio_val = float(precio_venta) if precio_venta else 0.0
    except ValueError:
        precio_val = 0.0
        
    fecha_venta = datetime.now().strftime("%d/%m/%Y %H:%M") if estatus == 'Asignada / Activa' else ''

    db = get_db_connection()
    db.execute('''
        INSERT INTO licencias_office 
        (clave_producto, version_office, tipo_licencia, precio_venta, nombre_cliente, telefono_cliente, equipo_asignado, fecha_venta, estatus, observaciones)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (clave_producto, version_office, tipo_licencia, precio_val, nombre_cliente, telefono_cliente, equipo_asignado, fecha_venta, estatus, observaciones))
    db.commit()
    db.close()
    
    flash("Licencia de Office registrada exitosamente.")
    return redirect(url_for('admin_office'))

@app.route('/borrar_licencia_office/<int:id>')
def borrar_licencia_office(id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    if session.get('user_rol') != 'admin':
        flash("Acceso denegado: Solo administradores pueden eliminar registros.")
        return redirect(url_for('admin_office'))
        
    db = get_db_connection()
    db.execute("DELETE FROM licencias_office WHERE id = ?", (id,))
    db.commit()
    db.close()
    
    flash("Registro de licencia eliminado.")
    return redirect(url_for('admin_office'))

# =====================================================
# MÓDULO DE LICENCIAS DE ANTIVIRUS
# =====================================================

from datetime import timedelta

@app.route('/admin_antivirus')
def admin_antivirus():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    db = get_db_connection()
    licencias = db.execute("SELECT * FROM licencias_antivirus ORDER BY id DESC").fetchall()
    
    # Clientes para autocompletar
    clientes = db.execute("""
        SELECT cliente, MAX(telefono) AS telefono 
        FROM notas_venta 
        WHERE cliente IS NOT NULL AND TRIM(cliente) != '' 
        GROUP BY cliente 
        ORDER BY cliente ASC
    """).fetchall()
    db.close()
    
    return render_template('admin_antivirus.html', licencias=licencias, clientes=clientes)

@app.route('/crear_licencia_antivirus', methods=['POST'])
def crear_licencia_antivirus():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    marca_antivirus = request.form.get('marca_antivirus', '').strip()
    edicion = request.form.get('edicion', '').strip()
    clave_licencia = request.form.get('clave_licencia', '').strip()
    dispositivos_totales = int(request.form.get('dispositivos_totales') or 1)
    dispositivos_usados = int(request.form.get('dispositivos_usados') or 0)
    duracion_meses = int(request.form.get('duracion_meses') or 12)
    precio_venta = request.form.get('precio_venta', '0').strip()
    nombre_cliente = request.form.get('nombre_cliente', '').strip()
    telefono_cliente = request.form.get('telefono_cliente', '').strip()
    equipo_instalado = request.form.get('equipo_instalado', '').strip()
    estatus = request.form.get('estatus', 'Disponible').strip()
    observaciones = request.form.get('observaciones', '').strip()
    
    raw_fecha_act = request.form.get('fecha_activacion', '').strip()
    fecha_vencimiento = request.form.get('fecha_vencimiento', '').strip()
    
    try:
        precio_val = float(precio_venta) if precio_venta else 0.0
    except ValueError:
        precio_val = 0.0

    fecha_activacion = ''
    if raw_fecha_act:
        try:
            dt_act = datetime.strptime(raw_fecha_act, "%Y-%m-%d")
            fecha_activacion = dt_act.strftime("%d/%m/%Y")
            if not fecha_vencimiento:
                dias_aprox = int(duracion_meses * 30.4)
                fecha_vencimiento = (dt_act + timedelta(days=dias_aprox)).strftime("%d/%m/%Y")
        except Exception:
            fecha_activacion = raw_fecha_act

    db = get_db_connection()
    db.execute('''
        INSERT INTO licencias_antivirus 
        (marca_antivirus, edicion, clave_licencia, dispositivos_totales, dispositivos_usados, duracion_meses, precio_venta, nombre_cliente, telefono_cliente, equipo_instalado, fecha_activacion, fecha_vencimiento, estatus, observaciones)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (marca_antivirus, edicion, clave_licencia, dispositivos_totales, dispositivos_usados, duracion_meses, precio_val, nombre_cliente, telefono_cliente, equipo_instalado, fecha_activacion, fecha_vencimiento, estatus, observaciones))
    db.commit()
    db.close()
    
    flash("Licencia de Antivirus registrada exitosamente.")
    return redirect(url_for('admin_antivirus'))

@app.route('/borrar_licencia_antivirus/<int:id>')
def borrar_licencia_antivirus(id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    if session.get('user_rol') != 'admin':
        flash("Acceso denegado: Solo administradores pueden eliminar registros.")
        return redirect(url_for('admin_antivirus'))
        
    db = get_db_connection()
    db.execute("DELETE FROM licencias_antivirus WHERE id = ?", (id,))
    db.commit()
    db.close()
    
    flash("Registro de antivirus eliminado.")
    return redirect(url_for('admin_antivirus'))

@app.route('/actualizar_estatus_nota/<int:id>', methods=['POST'])
def actualizar_estatus_nota(id):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    nuevo_estatus = request.form.get('estatus', '').strip()
    if nuevo_estatus:
        db = get_db_connection()
        db.execute("UPDATE notas_venta SET estatus = ? WHERE id = ?", (nuevo_estatus, id))
        db.commit()
        db.close()
        flash(f"Estatus de la nota #{1000 + id} actualizado a: {nuevo_estatus}")

    return redirect(url_for('ver_notas'))


# --- RASTREO PÚBLICO DE EQUIPOS ---
@app.route('/rastreo', methods=['GET', 'POST'])
def rastreo():
    nota_encontrada = None
    busqueda_realizada = False
    query = ""

    if request.method == 'POST':
        query = request.form.get('busqueda', '').strip()
        busqueda_realizada = True

        if query:
            db = get_db_connection()
            id_busqueda = None
            if query.isdigit():
                num = int(query)
                id_busqueda = num - 1000 if num > 1000 else num

            if id_busqueda is not None:
                nota_encontrada = db.execute(
                    "SELECT * FROM notas_venta WHERE id = ? OR telefono LIKE ? ORDER BY id DESC LIMIT 1",
                    (id_busqueda, f"%{query}%")
                ).fetchone()
            else:
                nota_encontrada = db.execute(
                    "SELECT * FROM notas_venta WHERE telefono LIKE ? ORDER BY id DESC LIMIT 1",
                    (f"%{query}%",)
                ).fetchone()

            db.close()

    return render_template('rastreo.html', nota=nota_encontrada, busqueda=query, realizada=busqueda_realizada)


@app.route('/changelog')
def changelog():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('changelog.html')

@app.route('/cctv')
def cctv():
    return render_template('cctv.html')

@app.route('/equipos')
def equipos():
    return render_template('equipos.html')

asegurar_admin_en_arranque()

# ==========================================
# WEBHOOK DE AUTO-DESPLIEGUE (TIPO RENDER)
# ==========================================
DEPLOY_SECRET = os.environ.get('DEPLOY_SECRET', 'gtek_deploy_secure_key_2026')

@app.route('/api/deploy-webhook', methods=['POST'])
def deploy_webhook():
    signature = request.headers.get('X-Hub-Signature-256')
    token_param = request.args.get('token')
    
    authorized = False
    if token_param and hmac.compare_digest(token_param, DEPLOY_SECRET):
        authorized = True
    elif signature:
        expected_sig = 'sha256=' + hmac.new(DEPLOY_SECRET.encode(), request.data, hashlib.sha256).hexdigest()
        if hmac.compare_digest(signature, expected_sig):
            authorized = True

    if not authorized:
        abort(403)

    event = request.headers.get('X-GitHub-Event', 'push')
    if event == 'push':
        payload = request.get_json(silent=True) or {}
        ref = payload.get('ref', '')
        if ref == 'refs/heads/main' or not ref:
            script_path = os.path.expanduser('~/gteksrv/deploy.sh')
            if os.path.exists(script_path):
                subprocess.Popen(['bash', script_path])
            return jsonify({'status': 'Deployment triggered successfully'}), 200

    return jsonify({'status': 'Ignored'}), 200

@app.route('/invitacion')
def invitacion_martini():
    return render_template('invitacion_martini.html')

if __name__ == '__main__':
    app.run(debug=False, threaded=False)